import os
import shutil

replaceChars = {'&amp;': '&'}
receivePath = './receive'
backupPath = './receive/pythonBackup'

def checkThenBackup():
    global replaceChars
    global receivePath 
    global backupPath 
    path, dirs, files = next(os.walk(receivePath))
    allWrong = []
    for file in files:
        if file.endswith(('.csv')): #check all file .csv
            try:
                with open(os.path.join(receivePath, file), "r", encoding='utf-8') as readFile: #read file
                    content = readFile.readlines()
                    readFile.close()
            except:
                continue
            eachLine= 0
            for line in content:
                checkVar = True
                wrongDetails = []
                for wrongKey in replaceChars.keys():
                    if line.find(wrongKey) != -1: #found
                        checkVar = False #detect wrong character
                        shutil.copyfile(os.path.join(receivePath, file), os.path.join(backupPath, file)) #backup
                        wrongDetails.append(file)     #0
                        wrongDetails.append(eachLine) #1
                        wrongDetails.append(line)     #2 
                        wrongDetails.append(wrongKey) #3    #grep each wrong line
                        allWrong.append(wrongDetails)       #grep all wrong lines
                        checkVar = True
                eachLine += 1 
    return allWrong
    
if __name__ == "__main__":
    while True:
        allWrong = checkThenBackup()
        if allWrong == None:
            continue
        for wrongDetails in allWrong:
            print (str(wrongDetails))
            with open(os.path.join(receivePath, wrongDetails[0]), "r", encoding='utf-8') as readFile: #read file
                content = readFile.readlines()
                readFile.close()
            eachLine= 0
            with open(os.path.join(receivePath, wrongDetails[0]), 'w', encoding='utf-8') as reWrite: #fix file
                for line in content:
                    if eachLine != wrongDetails[1]:
                        reWrite.write(line)
                    else:
                        reWrite.writelines(line.replace(wrongDetails[3], replaceChars[wrongDetails[3]])) #remove wrong char
                    eachLine += 1
                reWrite.close()